<?php
echo "<table border=1 cellspacing=0 cellpading=0>
<tr> <td>Random Text_1 </td> <td>Random Text_2</td></tr> 
<tr> <td>Random Text_3</td> <td>Random Text_4</td></tr>
<tr> <td>Random Text_5</td> <td>Random Text_6</td></tr>
<tr> <td>Random Text_7</td> <td>Random Text_8</td></tr>
</table>";
?>