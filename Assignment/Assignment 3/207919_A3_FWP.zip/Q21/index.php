<?php
$color = array(4 => 'white', 6 => 'green', 11=> 'red');
echo reset($color) . "
";
?>