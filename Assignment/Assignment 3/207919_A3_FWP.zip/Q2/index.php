<?php
echo "Tomorrow I \'ll learn PHP global variables.<br>";
echo "This is a bad command : del c:\\*.*<br>";
?>