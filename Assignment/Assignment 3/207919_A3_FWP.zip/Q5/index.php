<?php
echo "Client IP Address = " . $_SERVER['REMOTE_ADDR'];
?>