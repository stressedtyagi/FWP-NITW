<?php
$fileName = dirname($_SERVER['PHP_SELF']) . "/" . basename($_SERVER['PHP_SELF']);
echo $fileName . "<br>";
?>