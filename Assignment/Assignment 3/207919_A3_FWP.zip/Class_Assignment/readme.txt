1. Please make database 'manager'
2. import manager.sql into that database before moving on